''' 
CIS 122 Fall 2020 Lab 1 Challenge
Author: Isabella Cortez
Credit: Lab Class with, Guzman Nateras
Description: Lab 1 Discount
'''
#day = Monday #Assign string to a variable
day = 'Monday' #Assign string to a variable
#square = 2 ^ 2 #Perform power operation
square = 2 ** 2 #Perform power operation
#print square #Output value of a variable
print(square) #Output value of a variable 
#print(day + square) #Target output is Monday (without quotation marks)
print(day, square) #Target output is Monday (without quotation marks)
