''' 
CIS 122 Fall 2020 Lab 1 Challenge
Author: Isabella Cortez
Credit: Lab Class with, Guzman Nateras
Description: Lab 1 Discount
'''
cost = 50
#type(cost)
discount = 0.10
#type(discount)
discounted_cost = cost - cost * discount
discounted_cost
print(discounted_cost)
print("Discount cost: ", discounted_cost)
