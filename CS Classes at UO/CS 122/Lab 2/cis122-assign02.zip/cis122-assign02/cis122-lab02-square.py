''' 
CIS 122 Fall 2020 Lab 2 (Square)
Author: Isabella Cortez
Credit: Lab Class with, Guzman Nateras
Description: Create a function that returns the square of any positive integer
'''

# Define a function that accepts a number
def square(number):

    # Verify the number is a positive integer (we will not be able to code this step yet)


    # Multiply the number by itself
    result = number * number

    # Return the result
    return result

# Test
print(str(square(2))+',',str(square(10))+',' ,str(square(100)))
