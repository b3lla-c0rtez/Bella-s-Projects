using namespace std;
#include <ctime>
#include <cstdlib>
#include <iostream>
#include <cstring> 
#define INTERVAL 10000

double rand_gen() {
    return static_cast<double>(rand()) / RAND_MAX;
}

int main (int argc, char* argv[]) {
	int i;
	int N = 1000000;
	double x, y, origin_dist, pi;
	int circle_points = 0; int square_points = 0;

	srand(time(NULL));

	if (argc >2 && strcmp(argv[1], "-numpoints")==0) {
		N = std::atoi(argv[2]);
	}

#pragma acc parallel loop reduction(+:circle_points, square_points)
	for (i=0; i<N; i++) {
		x = rand_gen();
		y = rand_gen();

		origin_dist = (x*x) + (y*y);

		if (origin_dist <= 1) {
			circle_points++;
		} else {
			square_points++;
		}
		//pi = double(4*circle_points)/N;
	}

	pi = double(4*circle_points)/N;

	cout.precision(4);
	std::cout << "Final estimation of pi: " << std::fixed << pi << endl;
	return 0;
}
