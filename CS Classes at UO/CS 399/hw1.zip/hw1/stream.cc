using namespace std;
#include <iostream>
#include <ctime>
#include <cstdlib>
#include <cstring>
#ifdef _OPENACC
#include <openacc.h>
#endif

int main(int argc, char* argv[]) {
	long long size_of_array = 1000;

	if (argc > 2 && strcmp(argv[1], "-size") == 0) {
        	size_of_array = std::stol(argv[2]);
    	}


	float *a, *b, *c;

	a = new float[size_of_array];
	b = new float[size_of_array];
	c = new float[size_of_array];

	for (int i = 0; i < size_of_array; i++) {
		a[i] = 1.0f;
		b[i] = 2.0f;
		c[i] = 0.0f;
	}


	float scalar = 4.0;
	


	clock_t start = clock();
#ifdef _OPENACC
#pragma acc parallel loop present(a, c)
#endif

	// benchmark1 = copy
	for (int i = 0; i<size_of_array; i++) {
		c[i] = a[i];
	}
	clock_t end = clock();	
	// standard output -- time
	double b1_time = static_cast<double>(end-start) / CLOCKS_PER_SEC;
	std::cout << "Copy; Benchmark time: " << b1_time << "s/t\n";

	// standard output -- memory
	double b1_memory = (size_of_array* sizeof(float)*2)/b1_time/1e9;
	std::cout << "Copy; Estimated memory bandwidth: " << b1_memory << "GB/s\n";


	start = clock();
#ifdef _OPENACC
#pragma acc parallel loop present(c)
#endif	
	// benchmark2 = scale
	for (int i = 0; i<size_of_array; i++) {
		b[i] = scalar*c[i];
	}
	end = clock();
	 // standard output -- time
        double b2_time = static_cast<double>(end-start) / CLOCKS_PER_SEC;
        std::cout << "Scale; Benchmark time: " << b2_time << "s/t\n";

        // standard output -- memory
        double b2_memory = (size_of_array* sizeof(float)*2)/b2_time/1e9;
        std::cout << "Scale; Estimated memory bandwidth: " << b2_memory << "GB/s\n";

	
	start = clock();
#ifdef _OPENACC
#pragma acc parallel loop present(a, b, c)
#endif	
	// benchmark3 = add
	for (int i = 0; i<size_of_array; i++) {
		c[i] = a[i] + b[i];
	}
	end = clock();
	// standard output -- time
        double b3_time = static_cast<double>(end-start) / CLOCKS_PER_SEC;
        std::cout << "Add; Benchmark time: " << b3_time << "s/t\n";

        // standard output -- memory
        double b3_memory = (size_of_array* sizeof(float)*2)/b3_time/1e9;
        std::cout << "Add; Estimated memory bandwidth: " << b3_memory << "GB/s\n";


	start = clock();
#ifdef _OPENACC
#pragma acc parallel loop present(a, b, c)
#endif	
	// benchmark4 = triad
	for (int i = 0; i<size_of_array; i++) {
		a[i] = b[i]+scalar*c[i];
	}
	end = clock();
	// standard output -- time
        double b4_time = static_cast<double>(end-start) / CLOCKS_PER_SEC;
        std::cout << "Triad; Benchmark time: " << b4_time << "s/t\n";

        // standard output -- memory
        double b4_memory = (size_of_array* sizeof(float)*2)/b4_time/1e9;
        std::cout << "Triad; Estimated memory bandwidth: " << b4_memory << "GB/s\n";



	delete[] a;
	delete[] b;
	delete[] c;

	return 0;
}
