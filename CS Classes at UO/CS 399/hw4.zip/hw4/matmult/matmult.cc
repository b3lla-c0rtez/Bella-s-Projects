using namespace std;
#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>

__global__ void multMat (int N, int M, float* A, float* B, float* C) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    int j = blockIdx.y * blockDim.y + threadIdx.y;

    if (i<N && j < N) {
        float sum = 0.0;
        
        for (int k = 0; k < M; k++) {
            sum += A[i*M+k] * B[k*N+j];
        }
        C[i * N + j] = sum;
	    
    }
}

void multiply(int N, int M, float* A, float* B, float* C) {
    dim3 blockSize(16, 16); 
    dim3 gridSize((N + blockSize.x - 1) / blockSize.x, (N + blockSize.y - 1) / blockSize.y);

    multMult<<<gridSize, blockSize>>>(N, M, A, B, C);
    cudaDeviceSynchronize();
}

int main (int argc, char *argv[]) {
    if (argc != 5) {
        std::cout << "Usage: ./matmult -n <N> -m <M>\n";
        return 1;
    }

    int N = std::atoi(argv[2]);
    int M = std::atoi(argv[4]);


    if (N <= 0 || M <= 0) {
        std::cout << "Invalid input for N or M \n";
        return 1;
    }

    float* A = new float[N*M];
    float* B = new float[M*N];
    float* C = new float[N*N];

    for (int i = 0; i<N*M; i++) {
    	A[i] = 1.0;
    }

    for (int i = 0; i<M*N; i++) {
    	B[i] = 1.0;
    }

    float* A_again, *B_again, *C_again;

    cudaMalloc((void**)&A_again, N * M * sizeof(float));
    cudaMalloc((void**)&B_again, M * N * sizeof(float));
    cudaMalloc((void**)&C_again, N * N * sizeof(float));

    cudaMemcpy(A_again, A, N * M * sizeof(float), cudaMemcpyHostToDevice);
    cudaMemcpy(B_again, B, M * N * sizeof(float), cudaMemcpyHostToDevice)


    clock_t start_time = clock();

    multiply(N, M, A_again, B_again, C_again);

    clock_t end_time = clock();

    cudaMemcpy(C, C_again, N * N * sizeof(float), cudaMemcpyDeviceToHost);

    std::cout << "Time taken: " << static_cast<double>(end_time - start_time) / CLOCKS_PER_SEC << " seconds\n";

    cudaFree(A_again);
    cudaFree(B_again);
    cudaFree(C_again);

    delete[] A;
    delete[] B;
    delete[] C; 

    return 0;
}
