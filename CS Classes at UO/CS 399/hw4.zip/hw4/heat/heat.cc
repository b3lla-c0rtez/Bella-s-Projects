using namespace std;
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <cstring>

const int BLOCK_SIZE = 16

__global__ void heatDis(float* A, float* Anew, int N, float tol, int max_iter) {
	float err = 1.0;

	for (int iter = 0; iter < max_iter && err > tol; ++iter) {
		err = 0.0;
		for (int i = 1; i < N-1; i++) {
				for (int j = 1; j < N-1; j++) {
					Anew[i][j] = (A[i+1][j] + A[i-1][j] + A[i][j-1] + A[i][j+1])/4;
					err = fmax(err, fabs(Anew[i][j] - A[i][j]));
				}
		}

	// yes you do have to do it like this, think about why
		for (int i = 1; i < N-1; i++) {
			for (int j = 1; j < N-1; j++) {
				A[i * N + j] = Anew[i * N + j];
			}
		}

		if (iter % 1000 == 0) {
			std::ofstream csvFile("heat_" + std::to_string(iter) + ".csv");
			csvFile << std::fixed<< std::setprecision(6);
			
			for (int i = 0; i < N; ++i) {
				for (int j=0; j<N; ++j) {
					csvFile << A[i*N+j];
					if (j < N-1) {
						csvFile << ",";
					}
				}
				csvFile << std::endl;
			}
			csvFile.close();
		}
	}
}

int main(int argc, char *argv[]) {
	int N = 10;
	float tol = 0.01;
	int max_iter = 1000;
	
	for (int i = 1; i<argc; i+=2) {
		if (strcmp(argv[i], "-n") == 0){
			N = atoi(argv[i+1]);
		} else if (strcmp(argv[i], "-tol")==0) {
			tol = atof(argv[i+1]);
		} else if (strcmp(argv[i], "-max_iter")==0){
            		max_iter = atoi(argv[i+1]);
        	}
	}

	float* A = new float[N*N];
	float* Anew = new float[N*N];

	for (int i=0; i<N; i++) {
		for (int j=0; j<N; j++) {
			A[i * N + j] = 0.0;
			Anew[i * N + j] = 0.0;
		}
	}

	for (int j=0; j<N; j++) {
		A[0 * N + j] = 100.0;
		Anew[0 * N + j] = 100.0;
	}	

	float* A_again;
	float* Anew_again;

	cudaMalloc((void**)&A_again, N * N * sizeof(float));
	cudaMalloc((void**)&Anew_again, N * N * sizeof(float));

	cudaMemcpy(A_again, A, N * N * sizeof(float), cudaMemcpyHostToDevice);
	cudaMemcpy(Anew_again, Anew, N * N * sizeof(float), cudaMemcpyHostToDevice);

	dim3 blocks((N - 1) / BLOCK_SIZE + 1, (N - 1) / BLOCK_SIZE + 1);
	dim3 threads(BLOCK_SIZE, BLOCK_SIZE);
	heatDis<<<blocks, threads>>>(A_again, Anew_again, N, tol, max_iter);

	cudaMemcpy(A, A_again, N * N * sizeof(float), cudaMemcpyDeviceToHost);


	std::ofstream csvFile("heat_final.csv");

	for (int i=0; i<N; i++) {
		for (int j=0; j<N; j++) {
			csvFile << A[i * N + j];
			if (j < N-1) {
				csvFile << ",";
			}	

		}		
		csvFile << endl;
	}
	csvFile.close();	

 	
    delete[] A;
    delete[] Anew;

	cudaFree(A_again);
    cudaFree(Anew_again);

    return 0;
}
