using namespace std;
#include <iostream>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <cstring>

__global__ void axpy(double *x, double *y, double alpha, long N) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    int j = blockIdx.y * blockDim.y + threadIdx.y;

     for (long i=0; i < N; ++i) {
        for (long j = 0; j<N; ++j) {
             y[i][j] += alpha * x[i][j];
        }
     }
}


int main(int argc, char *argv[]) {
    int N = 1024;

    if (argc = 3 && strcmp(argv[1], "-n")==0) {
		N = std::atoi(argv[2]);
	}

    const int size = N * N;
    const int bytes = size * sizeof(double);

    double *x = new double[size];
    double *y = new double[size];


    for (long i=0; i < size; ++i) {
	    x[i] = 1.0;
	    y[i] = 2.0;
    }

    double* x_again;
    double* y_again;

    cudaMalloc((void**)&x_again, bytes);
    cudaMalloc((void**)&y_again, bytes);

    cudaMemcpy(x_again, x, bytes, cudaMemcpyHostToDevice);
    cudaMemcpy(y_again, y, bytes, cudaMemcpyHostToDevice);

    dim3 threadsPerBlock(16, 16);
    dim3 numBlocks((N + threadsPerBlock.x - 1) / threadsPerBlock.x,
                   (N + threadsPerBlock.y - 1) / threadsPerBlock.y);

    double alpha = 1.5;
    axpy<<<numBlocks, threadsPerBlock>>>(x_again, y_again, alpha, N);

    cudaMemcpy(y, y_again, bytes, cudaMemcpyDeviceToHost);


    bool check = true;
    for (long i=0; i < N; ++i) {
        for (long j = 0; j<N; ++j) {
            if (y[i*N+j] != 3.5) {
                check = false;
                break;
            }
        }
        if (!check) {
            break;
        }
    }

    if (check) {
        std::cout << "Verification successful \n";
    } else {
        std::cout << "Verification failed \n";
    }


    delete[] x;
    delete[] y;

    cudaFree(x_again);
    cudaFree(y_again);

    return 0;

}
