using namespace std;
#include <iostream>
#include <fstream>
#include <string>
#include <ncurses.h> 
#define MAX_ITER 1000
#define MAX_ZOOM 1000.0

int main(int argc, char *argv[]) {
	int numx, numy, stopZooming;
	double zoom = 1.0;
	double zoomX, zoomY;

	for (int i = 1; i<argc; i+=2) {
		if (std::string(argv[i]) == "-numx"){
			numx = std::stoi(argv[i+1]);
		} else if (std::string(argv[i]) == "-numy") {
			numy = std::stoi(argv[i+1]);
		} else if (std::string(argv[i]) == "-zoom") {
			stopZooming = std::stoi(argv[i+1]); 
		} else if (std::string(argv[i]) == "-zoomX") {
			zoomX = std::stod(argv[i+1]);
		} else if (std::string(argv[i]) == "-zoomY") {
			zoomY = std::stod(argv[i+1]);
		}
	}
	
	int *results = new int[numx*numy];
	//double zoomX = -0.76;
	//double zoomY = 0.01;
	char userInput;


	while (true){
		// std::cout << "zoom level is: " << zoom << endl;
#pragma acc parallel loop copy(results[:numx*numy]) collapse(2)
		for (int i = 0; i<numx; i++) {
			for (int j = 0; j<numy; j++) {
				double x_old = zoomX+3.0*i/(numx-1) / zoom+zoomX;
				double y_old = zoomY+4.0*j/(numy-1) / zoom+zoomY;

				int iter = 0;
				double x_new = 0.0;
				double y_new = 0.0;
				double x_temp;

				while (x_new*x_new + y_new*y_new <= 4 && iter < MAX_ITER) {
					x_temp = x_new*x_new - y_new*y_new + x_old;
					y_new = 2*x_new*y_new + y_old;
					x_new = x_temp;
					iter = iter+1;
				}

				int index = i*numy+j;
				results[index] = iter;
			}
		}
		zoom*=1.1;
	
        	std::cout << "current zoom: " << zoom << endl;

		// std::cout << "press q to exit the zoom loop: ";
		// std::cin >> userInput;

		if (zoom >= stopZooming || userInput == 'q' || userInput == 'Q') {
#pragma acc update host (results[:numx*numy])
			break;
		}
		
		
		//if (zoom >= stopZooming) {
		//	std::cout << "stopping infinite zoom here" << std::endl;
		//	break;
		//}

	}

    	endwin();
	
	std::ofstream file;

	file.open("mandelbrot.csv");

        if (!file.is_open()) {
                std::cerr << "error opening file" << std::endl;
                delete[] results;
		return 1;
 	}

	for (int j=0; j<numy; j++) {
		for (int i=0; i<numx; i++) {
			file << results[i * numy + j];
			if (i < numx-1) {
				file<<",";
			}
		}
		file << "\n";
	}
	
	
	file.close();
	delete[] results;
	return 0;

}
