using namespace std;
#include <iostream>
#include <ctime>
#include <cstdlib>
#include <cstring>
#include <cuda_runtime.h>
#include <curand_kernel.h>
#define CUDA_CHECK(call) \
    do { \
        cudaError_t status = call; \
        if (status != cudaSuccess) { \
            std::cerr << "CUDA error at " << __FILE__ << ":" << __LINE__ << ": " << cudaGetErrorString(status) << std::endl; \
            exit(EXIT_FAILURE); \
        } \
    } while (0)

__global__ void copy_kernel(const float *a, float *c, int size) {
    int tid = blockDim.x * blockDim.x + threadIdx.x;
    if (tid < size) {
        c[tid] = a[tid];
    }
}

__global__ void scale_kernel(float *b, const float *c, float scalar, int size) {
    int tid = blockDim.x * blockDim.x + threadIdx.x;
    if (tid < size) {
        b[tid] = scalar * c[tid];
    }
}

__global__ void add_kernel(float *c, const float *a, const float *b, int size) {
    int tid = blockDim.x * blockDim.x + threadIdx.x;
    if (tid < size) {
        c[tid] = a[tid] + b[tid];
    }
}

__global__ void triad_kernel(float *a, const float *b, const float *c, float scalar, int size) {
    int tid = blockDim.x * blockDim.x + threadIdx.x;
    if (tid < size) {
        a[tid] = b[tid] + scalar * c[tid];
    }
}

int main(int argc, char* argv[]) {
	long long size_of_array = 1000;

	if (argc > 2 && strcmp(argv[1], "-size") == 0) {
        	size_of_array = std::stol(argv[2]);
    	}


	float *a, *b, *c;
	float *d_a, *d_b, *d_c;

	a = new float[size_of_array];
	b = new float[size_of_array];
	c = new float[size_of_array];

	CUDA_CHECK(cudaMalloc((void**)&d_a, size_of_array * sizeof(float)));
    CUDA_CHECK(cudaMalloc((void**)&d_b, size_of_array * sizeof(float)));
    CUDA_CHECK(cudaMalloc((void**)&d_c, size_of_array * sizeof(float)));

	for (int i = 0; i < size_of_array; i++) {
		a[i] = 1.0f;
		b[i] = 2.0f;
		c[i] = 0.0f;
	}

	CUDA_CHECK(cudaMemcpy(d_a, a, size_of_array * sizeof(float), cudaMemcpyHostToDevice));
	CUDA_CHECK(cudaMemcpy(d_b, b, size_of_array * sizeof(float), cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemcpy(d_c, c, size_of_array * sizeof(float), cudaMemcpyHostToDevice));

	float scalar = 4.0;
	

	// benchmark1 = copy
	clock_t start = clock();

	copy_kernel<<<(size_of_array + 255) / 256, 256>>>(d_a, d_c, size_of_array);
    CUDA_CHECK(cudaDeviceSynchronize());
	
	clock_t end = clock();	

	// benchmark 1 output
	// standard output -- time
	double b1_time = static_cast<double>(end-start) / CLOCKS_PER_SEC;
	std::cout << "Copy; Benchmark time: " << b1_time << "s/t\n";

	// standard output -- memory
	double b1_memory = (size_of_array* sizeof(float)*2)/b1_time/1e9;
	std::cout << "Copy; Estimated memory bandwidth: " << b1_memory << "GB/s\n";


	// benchmark2 = scale
	start = clock();

	scale_kernel<<<(size_of_array + 255) / 256, 256>>>(d_a, d_c, size_of_array);
    CUDA_CHECK(cudaDeviceSynchronize());
	
	end = clock();
	// benchmark 2 output
	// standard output -- time
    double b2_time = static_cast<double>(end-start) / CLOCKS_PER_SEC;
    std::cout << "Scale; Benchmark time: " << b2_time << "s/t\n";

    // standard output -- memory
    double b2_memory = (size_of_array* sizeof(float)*2)/b2_time/1e9;
    std::cout << "Scale; Estimated memory bandwidth: " << b2_memory << "GB/s\n";

	
	// benchmark3 = add
	start = clock();
	
	add_kernel<<<(size_of_array + 255) / 256, 256>>>(d_c, d_a, d_b, size_of_array);
    CUDA_CHECK(cudaDeviceSynchronize());

	end = clock();
	// benchmark 3 output
	// standard output -- time
    double b3_time = static_cast<double>(end-start) / CLOCKS_PER_SEC;
    std::cout << "Add; Benchmark time: " << b3_time << "s/t\n";

    // standard output -- memory
    double b3_memory = (size_of_array* sizeof(float)*2)/b3_time/1e9;
    std::cout << "Add; Estimated memory bandwidth: " << b3_memory << "GB/s\n";

	
	// benchmark4 = triad
	start = clock();

	triad_kernel<<<(size_of_array + 255) / 256, 256>>>(d_a, d_b, d_c, scalar, size_of_array);
    CUDA_CHECK(cudaDeviceSynchronize());
	
	end = clock();
	// benchmark 4 output
	// standard output -- time
    double b4_time = static_cast<double>(end-start) / CLOCKS_PER_SEC;
    std::cout << "Triad; Benchmark time: " << b4_time << "s/t\n";

    // standard output -- memory
    double b4_memory = (size_of_array* sizeof(float)*2)/b4_time/1e9;
    std::cout << "Triad; Estimated memory bandwidth: " << b4_memory << "GB/s\n";

	CUDA_CHECK(cudaMemcpy(a, d_a, size_of_array * sizeof(float), cudaMemcpyDeviceToHost));


	delete[] a;
	delete[] b;
	delete[] c;

	CUDA_CHECK(cudaFree(d_a));
    CUDA_CHECK(cudaFree(d_b));
    CUDA_CHECK(cudaFree(d_c));


	return 0;
}
