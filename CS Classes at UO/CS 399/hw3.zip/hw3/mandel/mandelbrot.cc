using namespace std;
#include <iostream>
#include <fstream>
#include <string>
#include <cuda_runtime.h>
#define MAX_ITER 1000

int main(int argc, char *argv[]) {
	int numx, numy;

	for (int i = 1; i<argc; i+=2) {
		if (std::string(argv[i]) == "-numx"){
			numx = std::stoi(argv[i+1]);
		} else if (std::string(argv[i]) == "-numy") {
			numy = std::stoi(argv[i+1]);
		}
	}
	
	int *results = new int[numx*numy];
	int *d_results;

	cudaMalloc((void **)&d_results, sizeof(int) * numx * numy);

	dim3 blockDim(16, 16); 
	dim3 gridDim((numx + blockDim.x - 1) / blockDim.x, (numy + blockDim.y - 1) / blockDim.y);

	for (int i = 0; i<numx; i++) {
		for (int j = 0; j<numy; j++) {
			//double x_old = (i-numx/2)*(4/numx);
			//double y_old = (j-numy/2)*(4/numy);
			double x_old = -2.0+3.0*i/(numx-1);
			double y_old = -2.0+4.0*j/(numy-1);

			int iter = 0;
			double x_new = 0.0;
			double y_new = 0.0;
			double x_temp;

			while (x_new*x_new + y_new*y_new <= 4 && iter < MAX_ITER) {
				x_temp = x_new*x_new - y_new*y_new + x_old;
				y_new = 2*x_new*y_new + y_old;
				x_new = x_temp;
				iter = iter+1;
			}

			int index = i*numy+j;
			results[index] = iter;
		}
		
	}

	cudaMemcpy(results, d_results, sizeof(int) * numx * numy, cudaMemcpyDeviceToHost);

    cudaFree(d_results);

	std::cout << results[6] << std::endl;

	std::ofstream file;

	file.open("mandelbrot.csv");

        if (!file.is_open()) {
                std::cerr << "error opening file" << std::endl;
                delete[] results;
		return 1;
 	}

	for (int j=0; j<numy; j++) {
		for (int i=0; i<numx; i++) {
			file << results[i * numy + j];
			if (i < numx-1) {
				file<<",";
			}
		}
		file << "\n";
	}
	file.close();
	delete[] results;
	return 0;

}
