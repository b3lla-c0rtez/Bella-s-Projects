using namespace std;
#include <ctime>
#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <cstring>
#include <cuda_runtime.h>
#include <curand_kernel.h>
#define INTERVAL 10000

__global__ void estimatePi(int N, int* circle_points, int* square_points, unsigned int seed) {
	int tid = threadIdx.x + blockDim.x * threadIdx.y;

    	curandState state;
    	curand_init(seed, tid, 0, &state);

    	int cp = 0;
    	int sp = 0;

    	for (int i = 0; i < N; i++) {
		double x = curand_uniform(&state);
		double y = curand_uniform(&state);

		double origin_dist = (x*x) + (y*y);

		if (origin_dist <= 1.0) {
			cp++;
		} else {
			sp++;
		}
	}

	atomicAdd(circle_points, cp);
    	atomicAdd(square_points, sp);

}

int main (int argc, char* argv[]) {
	int i;
	int N = 1000000;
	double x, y, origin_dist, pi;
	int circle_points = 0; int square_points = 0;

	srand(time(NULL));

	if (argc >2 && strcmp(argv[1], "-numpoints")==0) {
		N = std::atoi(argv[2]);
	}

	int* d_circle_points;
    	int* d_square_points;

    	cudaMalloc((void**)&d_circle_points, sizeof(int));
    	cudaMalloc((void**)&d_square_points, sizeof(int));

	cudaMemcpy(d_circle_points, &circle_points, sizeof(int), cudaMemcpyHostToDevice);
    	cudaMemcpy(d_square_points, &square_points, sizeof(int), cudaMemcpyHostToDevice);

    	int threadsPerBlock = 256;
    	int blocksPerGrid = (N + threadsPerBlock - 1) / threadsPerBlock;

	unsigned int seed = time(NULL);

	estimatePi<<<blocksPerGrid, threadsPerBlock>>>(N, d_circle_points, d_square_points, seed);

	cudaMemcpy(&circle_points, d_circle_points, sizeof(int), cudaMemcpyDeviceToHost);
    	cudaMemcpy(&square_points, d_square_points, sizeof(int), cudaMemcpyDeviceToHost);

	cudaFree(d_circle_points);
    	cudaFree(d_square_points);

	pi = double(4*circle_points)/N;

	cout.precision(4);
	std::cout << "Final estimation of pi: " << std::fixed << pi << endl;
	return 0;
}
