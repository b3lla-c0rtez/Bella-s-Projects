using namespace std;
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <cstring>

int main(int argc, char *argv[]) {
	int N = 10;
	float tol = 0.01;
	int max_iter = 1000;
	
	for (int i = 1; i<argc; i+=2) {
		if (strcmp(argv[i], "-n") == 0){
			N = atoi(argv[i+1]);
		} else if (strcmp(argv[i], "-tol")==0) {
			tol = atof(argv[i+1]);
		} else if (strcmp(argv[i], "-max_iter")==0){
            		max_iter = atoi(argv[i+1]);
        	}
	}

    	float** A = new float*[N];
    	float** Anew = new float*[N];

    	for(int i=0; i<N; i++) {
        	A[i] = new float[N];
        	Anew[i] = new float[N];
    	}

    	for (int i=0; i<N; i++) {
        	for (int j=0; j<N; j++) {
            		A[i][j] = 0.0;
            		Anew[i][j] = 0.0;
        	}
    	}

    	for (int j=0; j<N; j++) {
        	A[0][j] = 100.0;
       	 	Anew[0][j] = 100.0;
    	}	

    	float err = 1.0;
    	int iter = 0;


    	while (err > tol && iter < max_iter) {
        	err = 0.0;
#pragma acc parallel loop collapse(2) reduction(max: err)
        	for (int i = 1; i < N-1; i++) {
            		for (int j = 1; j < N-1; j++) {
                		Anew[i][j] = (A[i+1][j] + A[i-1][j] + A[i][j-1] + A[i][j+1])/4;
                		err = fmax(err, fabs(Anew[i][j] - A[i][j]));
            		}
        	}

        // yes you do have to do it like this, think about why
#pragma acc parallel loop collapse(2)
        	for (int i = 1; i < N-1; i++) {
            		for (int j = 1; j < N-1; j++) {
                		A[i][j] = Anew[i][j];
            		}
        	}
    
        	iter++;	

		if (iter % 1000 == 0) {
            		std::ofstream csvFile("heat_" + std::to_string(iter) + ".csv");
            		for (int i=0; i<N; i++) {
                		for (int j=0; j<N; j++) {
                    			csvFile << Anew[i][j];
                    			if (j < N-1) {
                        			csvFile<<",";
                    			}	
                
            			}		
				csvFile << endl;
			}
			csvFile.close();
	    	}	


	}

    for (int i=0; i<N; i++) {
        delete[] A[i];
        delete[] Anew[i];
    }
 	
    delete[] A;
    delete[] Anew;

    return 0;
}
