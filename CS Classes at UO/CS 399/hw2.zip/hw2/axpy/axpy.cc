using namespace std;
#include <iostream>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <cstring>

void axpy(double **x, double **y, double alpha, long N) {
#pragma acc parallel loop gang worker vector collapse(2)
     for (long i=0; i < N; ++i) {
        for (long j = 0; j<N; ++j) {
             y[i][j] += alpha * x[i][j];
        }
     }
}


int main(int argc, char *argv[]) {
    int N = 1024;

    if (argc = 3 && strcmp(argv[1], "-n")==0) {
		N = std::atoi(argv[2]);
	}
    
    double **x = new double*[N];
    double **y = new double*[N];

    for (long i=0; i < N; ++i) {
        x[i] = new double[N];
        y[i] = new double[N];
    }

#pragma acc parallel loop collapse(2)
    for (long i=0; i < N; ++i) {
        for (long j = 0; j<N; ++j) {
            x[i][j] = 1.0;
            y[i][j] = 2.0;
        }
    }

    double alpha = 1.5;
    axpy(x, y, alpha, N);
#pragma acc update self(y[0:N*N])


    bool check = true;
    for (long i=0; i < N; ++i) {
        for (long j = 0; j<N; ++j) {
            if (y[i][j] != 3.5) {
                check = false;
                break;
            }
        }
        if (!check) {
            break;
        }
    }

    if (check) {
        std::cout << "Verification successful \n";
    } else {
        std::cout << "Verification failed \n";
    }

    for (long i=0; i < N; ++i) {
        delete[] x[i];
        delete[] y[i];
    }

    delete[] x;
    delete[] y;

    return 0;

}
