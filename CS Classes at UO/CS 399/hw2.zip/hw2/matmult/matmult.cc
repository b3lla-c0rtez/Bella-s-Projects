using namespace std;
#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>

void multiply (int N, int M, float* A, float* B, float* C) {
#pragma acc parallel loop collapse(2)
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            float sum = 0.0;
#pragma acc loop seq
            for (int k = 0; k < M; k++) {
                sum += A[i*M+k] * B[k*N+j];
            }
	    C[i * N + j] = sum;
	}
    }
}

int main (int argc, char *argv[]) {
    if (argc != 5) {
        std::cout << "Usage: ./matmult -n <N> -m <M>\n";
        return 1;
    }

    int N = std::atoi(argv[2]);
    int M = std::atoi(argv[4]);


    if (N <= 0 || M <= 0) {
        std::cout << "Invalid input for N or M \n";
        return 1;
    }

    float* A = new float[N*M];
    float* B = new float[M*N];
    float* C = new float[N*N];

    for (int i = 0; i<N*M; i++) {
    	A[i] = 1.0;
    }

    for (int i = 0; i<M*N; i++) {
    	B[i] = 1.0;
    }

    clock_t start_time = clock();
#pragma acc data copyin(A[0:N*M], B[0:M*N]) copyout(C[0:N*N])

{
    multiply(N, M, A, B, C);
}
    clock_t end_time = clock();

    std::cout << "Time taken: " << static_cast<double>(end_time - start_time) / CLOCKS_PER_SEC << " seconds\n";

    delete[] A;
    delete[] B;
    delete[] C; 

    return 0;
}
